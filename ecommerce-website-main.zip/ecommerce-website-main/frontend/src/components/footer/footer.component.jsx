import React from "react";
import "./footer.styles.scss";
export default function Footer() {
  return (
    <footer>
      <p>
        Copyrights &copy; 2020 . design by{" "}
        <a href="https://www.linkedin.com/in/ajay-meena1/">Ajay</a>
      </p>
    </footer>
  );
}
